//
// Title       : ALU
// Design      : dsd_project
// Author      : proloykarmakar2022@outlook.com
// Company     : KUET
//
//-----------------------------------------------------------------------------
//
// File        : C:/Users/prolo/OneDrive/Desktop/4-2/DSD Lab/DSD_Project_Unit_Converter/dsd_project/src/ParallelAdder.v
// Generated   : Fri Jan 10 22:03:53 2025
// From        : Interface description file
// By          : ItfToHdl ver. 1.0
//
//-----------------------------------------------------------------------------
//
// Description : 
//
//-----------------------------------------------------------------------------

`timescale 1ps / 1ps

//{{ Section below this comment is automatically maintained
//    and may be overwritten
//{module {ALU}}

module ALU (
	input wire clk,
	input wire [3:0] current_state, 
    input wire [10:0] pla_output
	//output reg Pz, Q1, E, ES
);

//}} End of automatically maintained section

// Enter your statements here //

wire [3:0] Ae, Be,in_Ae, adder1_out, adder2_out, adder3_out, complemented_Ae, Af, Q, P, Q_out, B_out;
wire in_E, adder1_cout, adder2_cout, adder3_cout, as_out, bs_out, xor_out, F;


	/*ParallelAdder adder1 (
	    .A(Ae),         
	    .B(Be),          
	    .Cin(0),      
	    .Out(adder1_out),      
	    .Cout(adder1_cout)     
	); 
	
	ParallelAdder adder2 (
	    .A(Ae),         
	    .B(~Be),          
	    .Cin(1),      
	    .Out(adder2_out),      
	    .Cout(adder2_cout)     
	);*/

	
	/*E_register e_register (
	    .clk(clk),   
	    .LE(pla_output[12]),     
	    .RE(pla_output[7]),     
	    .in((~pla_output[0] & ~pla_output[1] & pla_output[2]) ? adder1_cout : 
	        (~pla_output[0] & pla_output[1] & ~pla_output[2]) ? adder2_cout : 
	        1'b0), 
	    .E(E)        
	);	*/

	
	Qs_register my_Qs_register (
        .clk(clk),     
        .LQs(pla_output[8]),     
        .D(xor_out)        
    );
	
	A_B_sign_register as_bs_register (
        .Bs(Bs_out), // Connect the Bs output to Bs_out
        .As(As_out)  // Connect the As output to As_out
    );
	
	xor_module xor_calc (
        .A(Bs_out),       
        .B(As_out),       
        .X(xor_out)       
    ); 
	
	F_register f_reg (
	    .clk(clk),
	    .L(pla_output[9]),
	    .R(pla_output[5]),
	    .D(adder3_cout),
	    .F(F)
	);
	
	A_register A_register( 
		.A(A)
	);
	
	
	Q_register q_register (
        .clk(clk),          
        .L(pla_output[7]),              
        .D((pla_output[0] & ~pla_output[1]) ? adder3_out :
		   (pla_output[0] & pla_output[1]) ? Q_out : 
			1'b0),              
        .Q(Q)               
    );
	
	
	ParallelAdder adder3 (
	    .A(Q),         
	    .B(Af),          
	    .Cin(0),      
	    .Out(adder3_out),      
	    .Cout(adder3_cout)     
	);
	
	P_register p_register (
        .clk(clk),         
        .DP(pla_output[8]),           
        .P(P)              
    );
	
	B_register b_register (
        .clk(clk),    
        .L(pla_output[10]),        
        .D(B_out),        
        .B(B)       
    );
	
	Right_shift_FQB uut (
        .clk(clk),
        .B(B),
        .Q(Q),
        .F(F),
        .Q_out(Q_out),
        .B_out(B_out)
    );
	
	/*
	always @(posedge clk) begin	
	#2
		$display("ALU | Current State: %b | Pla output: %b | S2 = %b |S1 = %b |S0 = %b | E = %b |L = %b", current_state, pla_output, pla_output[0],pla_output[1],pla_output[2], E, pla_output[4]);
    end
	*/

endmodule
