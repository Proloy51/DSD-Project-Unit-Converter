//-----------------------------------------------------------------------------
//
// Title       : Q_register
// Design      : dsd_project
// Author      : proloykarmakar2022@outlook.com
// Company     : KUET
//
//-----------------------------------------------------------------------------
//
// File        : C:/Users/prolo/OneDrive/Desktop/4-2/DSD Lab/DSD_Project_Unit_Converter/dsd_project/src/ParallelAdder.v
// Generated   : Sun Jan 19 18:27:53 2025
// From        : Interface description file
// By          : ItfToHdl ver. 1.0
//
//-----------------------------------------------------------------------------
//
// Description : 
//
//-----------------------------------------------------------------------------

`timescale 1ps / 1ps

//{{ Section below this comment is automatically maintained
//    and may be overwritten
//{module {Q_register}}

module Q_register (
    input clk,       
    input L,          
    input [3:0] D,    
    output reg [3:0] Q 
);

    always @(posedge clk) begin
        if (L) begin
            Q <= D;  
        end
    end

endmodule


