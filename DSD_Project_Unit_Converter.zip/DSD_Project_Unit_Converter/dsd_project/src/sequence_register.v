//-----------------------------------------------------------------------------
//
// Title       : sequence_register
// Design      : control
// Author      : proloy
// Company     : KUET
//
//-----------------------------------------------------------------------------
//
// File        : H:/control_unit/control/src/sequence_register.v
// Generated   : Wed Jan 15 13:42:17 2025
// From        : Interface description file
// By          : ItfToHdl ver. 1.0
//
//-----------------------------------------------------------------------------
//
// Description : 
//
//-----------------------------------------------------------------------------

`timescale 1ps / 1ps

//{{ Section below this comment is automatically maintained
//    and may be overwritten
//{module {sequence_register}}


module sequence_register (
    input wire clk,              // Clock signal
    input wire [3:0] next_state, // Next state input (4-bit example)
    output reg [3:0] current_state // Current state output (4-bit)
);


	initial begin
        current_state = 4'b0000;      
    end	   
	
    // Sequential logic for state update
    always @(*) begin	 
		//$display("Sequence Register | Time: %0t | Next State: %b | Updated Current State: %b", $time, next_state, current_state);
        #2
		current_state <= next_state; // Update current state with next state
    end

endmodule

