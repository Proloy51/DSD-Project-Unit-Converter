//-----------------------------------------------------------------------------
//
// Title       : ParallelAdder
// Design      : dsd_project
// Author      : proloykarmakar2022@outlook.com
// Company     : KUET
//
//-----------------------------------------------------------------------------
//
// File        : C:/Users/prolo/OneDrive/Desktop/4-2/DSD Lab/DSD_Project_Unit_Converter/dsd_project/src/ParallelAdder.v
// Generated   : Fri Jan 10 22:03:53 2025
// From        : Interface description file
// By          : ItfToHdl ver. 1.0
//
//-----------------------------------------------------------------------------
//
// Description : 
//
//-----------------------------------------------------------------------------

`timescale 1ps / 1ps

//{{ Section below this comment is automatically maintained
//    and may be overwritten
//{module {xor_module}}

module xor_module (
    input A,   
    input B,    
    output X   
);

    wire notA, notB;  
    wire and1, and2;  

    assign notA = ~A;
    assign notB = ~B;

    assign and1 = A & notB;
    assign and2 = notA & B;

    assign X = and1 | and2;

endmodule

