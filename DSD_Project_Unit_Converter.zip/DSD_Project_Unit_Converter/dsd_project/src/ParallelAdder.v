//-----------------------------------------------------------------------------
//
// Title       : ParallelAdder
// Design      : dsd_project
// Author      : proloykarmakar2022@outlook.com
// Company     : KUET
//
//-----------------------------------------------------------------------------
//
// File        : C:/Users/prolo/OneDrive/Desktop/4-2/DSD Lab/DSD_Project_Unit_Converter/dsd_project/src/ParallelAdder.v
// Generated   : Fri Jan 10 22:03:53 2025
// From        : Interface description file
// By          : ItfToHdl ver. 1.0
//
//-----------------------------------------------------------------------------
//
// Description : 
//
//-----------------------------------------------------------------------------

`timescale 1ps / 1ps

module ParallelAdder (
    input [3:0] A,     
    input [3:0] B,     
    input Cin,         
    output [3:0] Out,  
    output Cout        
);

    
    wire C1, C2, C3;

    // calling Full Adders
    FullAdder fa0 (
        .A(A[0]),
        .B(B[0]),
        .Cin(Cin),
        .Sum(Out[0]),
        .Cout(C1)
    );

    FullAdder fa1 (
        .A(A[1]),
        .B(B[1]),
        .Cin(C1),
        .Sum(Out[1]),
        .Cout(C2)
    );

    FullAdder fa2 (
        .A(A[2]),
        .B(B[2]),
        .Cin(C2),
        .Sum(Out[2]),
        .Cout(C3)
    );

    FullAdder fa3 (
        .A(A[3]),
        .B(B[3]),
        .Cin(C3),
        .Sum(Out[3]),
        .Cout(Cout)
    );

endmodule
