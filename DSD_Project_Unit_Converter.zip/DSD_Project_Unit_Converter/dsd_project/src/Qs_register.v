//-----------------------------------------------------------------------------
//
// Title       : Qs_register
// Design      : dsd_project
// Author      : proloykarmakar2022@outlook.com
// Company     : KUET
//
//-----------------------------------------------------------------------------
//
// File        : C:/Users/prolo/OneDrive/Desktop/4-2/DSD Lab/DSD_Project_Unit_Converter/dsd_project/src/ParallelAdder.v
// Generated   : Fri Jan 10 22:03:53 2025
// From        : Interface description file
// By          : ItfToHdl ver. 1.0
//
//-----------------------------------------------------------------------------
//
// Description : 
//
//-----------------------------------------------------------------------------

`timescale 1ps / 1ps


module Qs_register (
    input clk,        
    input LQs,        
    input D,     
); 

	reg Qs;

    always @(posedge clk) begin
         if (LQs) begin
            Qs <= D;
        end
    end

endmodule

