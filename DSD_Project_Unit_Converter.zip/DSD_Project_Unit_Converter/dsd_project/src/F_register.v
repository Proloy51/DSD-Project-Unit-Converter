//-----------------------------------------------------------------------------
//
// Title       : P_check
// Design      : dsd_project
// Author      : proloykarmakar2022@outlook.com
// Company     : KUET
//
//-----------------------------------------------------------------------------
//
// File        : C:/Users/prolo/OneDrive/Desktop/4-2/DSD Lab/DSD_Project_Unit_Converter/dsd_project/src/ParallelAdder.v
// Generated   : Fri Jan 10 22:03:53 2025
// From        : Interface description file
// By          : ItfToHdl ver. 1.0
//
//-----------------------------------------------------------------------------
//
// Description : 
//
//-----------------------------------------------------------------------------

`timescale 1ps / 1ps

//{{ Section below this comment is automatically maintained
//    and may be overwritten
//{module {F_register}}

module F_register (
    input clk,        
    input L,          
    input R,
	input D,
    output reg F      
);

    always @(posedge clk or posedge R) begin
        if (R) begin
            F <= 1'b0;  
        end
        else if (L) begin
            F <= D;  
        end
    end

endmodule

