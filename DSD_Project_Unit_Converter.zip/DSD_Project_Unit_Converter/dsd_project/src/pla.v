//-----------------------------------------------------------------------------
//
// Title       : ParallelAdder
// Design      : dsd_project
// Author      : proloykarmakar2022@outlook.com
// Company     : KUET
//
//-----------------------------------------------------------------------------
//
// File        : C:/Users/prolo/OneDrive/Desktop/4-2/DSD Lab/DSD_Project_Unit_Converter/dsd_project/src/ParallelAdder.v
// Generated   : Fri Jan 10 22:03:53 2025
// From        : Interface description file
// By          : ItfToHdl ver. 1.0
//
//-----------------------------------------------------------------------------
//
// Description : 
//
//-----------------------------------------------------------------------------


/*
`timescale 1ps / 1ps

module pla (
    input [3:0] Gin, 
    input Pz, Q1, mul, st, ip, 
    output reg [3:0] Gout, 
    output reg [8:0] out
);

always @(*) begin
    // Initialize outputs
    out = 8'b0000_0000;
    Gout = 4'b0010;

    // Assign values to `out` array
    out[0] = (~Gin[3] & Gin[2] & ~Gin[1] & ~Gin[0]) | (~Gin[3] & Gin[2] & Gin[1] & Gin[0] & ~Pz) | (~Gin[3] & Gin[2] & Gin[1] & Gin[0] & Pz);	// S1
    out[1] = (~Gin[3] & ~Gin[2] & Gin[1] & Gin[0]) | (~Gin[3] & Gin[2] & Gin[1] & Gin[0] & ~Pz) | (~Gin[3] & Gin[2] & Gin[1] & Gin[0] & Pz);    // S0
    out[2] = (~Gin[3] & ~Gin[2] & ~Gin[1] & Gin[0] & ip);																			           // La
    out[3] = (~Gin[3] & ~Gin[2] & Gin[1] & Gin[0]);																							  //  LQs
    out[4] = (~Gin[3] & ~Gin[2] & ~Gin[1] & Gin[0] & ip);  // Cq
    out[5] = (~Gin[3] & ~Gin[2] & ~Gin[1] & Gin[0] & ip) | (~Gin[3] & Gin[2] & Gin[1] & Gin[0] & ~Pz) | (~Gin[3] & Gin[2] & Gin[1] & Gin[0] & Pz);	// Cf
    out[6] = (~Gin[3] & ~Gin[2] & Gin[1] & Gin[0] & ip);	// Lp
    out[7] = (~Gin[3] & ~Gin[2] & Gin[1] & Gin[0]) | (~Gin[3] & Gin[2] & ~Gin[1] & Gin[0]);;		   // Lq
    out[8] = (~Gin[3] & Gin[2] & Gin[1] & ~Gin[0]); // Dp
   
	
	// Assign values to `Gout` array
    Gout[0] = (~Gin[3] & ~Gin[2] & ~Gin[1] & ~Gin[0] & st) | (~Gin[3] & ~Gin[2] & ~Gin[1] & Gin[0] & ~ip) | (~Gin[3] & ~Gin[2] & Gin[1] & ~Gin[0] & mul) | (~Gin[3] & Gin[2] & ~Gin[1] & ~Gin[0] & ~Q1) | (~Gin[3] & Gin[2] & ~Gin[1] & Gin[0]) | (Gin[3] & ~Gin[2] & ~Gin[1] & ~Gin[0]);  
	Gout[1] = (~Gin[3] & ~Gin[2] & ~Gin[1] & Gin[0] & ip) | (~Gin[3] & ~Gin[2] & Gin[1] & ~Gin[0] & ~mul) | (~Gin[3] & ~Gin[2] & Gin[1] & ~Gin[0] & mul) | (~Gin[3] & Gin[2] & ~Gin[1] & ~Gin[0] & ~Q1) | (~Gin[3] & Gin[2] & ~Gin[1] & Gin[0]) | (~Gin[3] & Gin[2] & Gin[1] & ~Gin[0]);	  
	Gout[2] = (~Gin[3] & ~Gin[2] & Gin[1] & Gin[0]) | (~Gin[3] & Gin[2] & ~Gin[1] & ~Gin[0] & ~Q1) | (~Gin[3] & Gin[2] & ~Gin[1] & Gin[0] & Q1) | (~Gin[3] & Gin[2] & ~Gin[1] & Gin[0]) | (~Gin[3] & Gin[2] & Gin[1] & ~Gin[0]) | (~Gin[3] & Gin[2] & Gin[1] & Gin[0] & Pz);
	Gout[3] = (~Gin[3] & Gin[2] & Gin[1] & Gin[0] & ~Pz) | (Gin[3] & ~Gin[2] & ~Gin[1] & ~Gin[0]);
end	 

$monitor(

endmodule 
*/

`timescale 1ps / 1ps

module pla (
    input [3:0] Gin, 
    input Pz, Q1, mul, st, ip, 
    output reg [3:0] Gout, 
    output reg [10:0] out
);

reg [3:0] current_state;
reg [3:0] next_state;

always @(*) begin
    // Initialize outputs
    out = 8'b0000_0000;
    Gout = 4'b0000;
	 
    // Assign values to `out` array
    out[0] = (~Gin[3] & Gin[2] & ~Gin[1] & ~Gin[0]) | (~Gin[3] & Gin[2] & Gin[1] & Gin[0] & ~Pz) | (~Gin[3] & Gin[2] & Gin[1] & Gin[0] & Pz);    // S1
    out[1] = (~Gin[3] & ~Gin[2] & Gin[1] & Gin[0]) | (~Gin[3] & Gin[2] & Gin[1] & Gin[0] & ~Pz) | (~Gin[3] & Gin[2] & Gin[1] & Gin[0] & Pz);    // S0
    out[2] = (~Gin[3] & ~Gin[2] & ~Gin[1] & Gin[0] & ip);                                                                                      // La
    out[3] = (~Gin[3] & ~Gin[2] & Gin[1] & Gin[0]);                                                                                              // LQs
    out[4] = (~Gin[3] & ~Gin[2] & ~Gin[1] & Gin[0] & ip);                                                                                       // Cq
    out[5] = (~Gin[3] & ~Gin[2] & ~Gin[1] & Gin[0] & ip) | (~Gin[3] & Gin[2] & Gin[1] & Gin[0] & ~Pz) | (~Gin[3] & Gin[2] & Gin[1] & Gin[0] & Pz); // Cf
    out[6] = (~Gin[3] & ~Gin[2] & Gin[1] & Gin[0] & ip);                                                                                       // Lp
    out[7] = (~Gin[3] & ~Gin[2] & Gin[1] & Gin[0]) | (~Gin[3] & Gin[2] & ~Gin[1] & Gin[0]);                                                    // Lq
    out[8] = (~Gin[3] & Gin[2] & Gin[1] & ~Gin[0]); // Dp
	out[9] = (Gin[3] & ~Gin[2] & ~Gin[1] & ~Gin[0]);  // Lf
	out[10] = (Gin[3] & ~Gin[2] & Gin[1] & ~Gin[0]);  // Lbf

    // Assign values to `Gout` array
    Gout[0] = (~Gin[3] & ~Gin[2] & ~Gin[1] & ~Gin[0] & st) | (~Gin[3] & ~Gin[2] & ~Gin[1] & Gin[0] & ~ip) | (~Gin[3] & ~Gin[2] & Gin[1] & ~Gin[0] & mul) | (~Gin[3] & Gin[2] & ~Gin[1] & ~Gin[0] & ~Q1) | (~Gin[3] & Gin[2] & ~Gin[1] & Gin[0]) | (Gin[3] & ~Gin[2] & ~Gin[1] & ~Gin[0]);  
    Gout[1] = (~Gin[3] & ~Gin[2] & ~Gin[1] & Gin[0] & ip) | (~Gin[3] & ~Gin[2] & Gin[1] & ~Gin[0] & ~mul) | (~Gin[3] & ~Gin[2] & Gin[1] & ~Gin[0] & mul) | (~Gin[3] & Gin[2] & ~Gin[1] & ~Gin[0] & ~Q1) | (~Gin[3] & Gin[2] & ~Gin[1] & Gin[0]) | (~Gin[3] & Gin[2] & Gin[1] & ~Gin[0]);      
    Gout[2] = (~Gin[3] & ~Gin[2] & Gin[1] & Gin[0]) | (~Gin[3] & Gin[2] & ~Gin[1] & ~Gin[0] & ~Q1) | (~Gin[3] & Gin[2] & ~Gin[1] & Gin[0] & Q1) | (~Gin[3] & Gin[2] & ~Gin[1] & Gin[0]) | (~Gin[3] & Gin[2] & Gin[1] & ~Gin[0]) | (~Gin[3] & Gin[2] & Gin[1] & Gin[0] & Pz);
    Gout[3] = (~Gin[3] & Gin[2] & Gin[1] & Gin[0] & ~Pz) | (Gin[3] & ~Gin[2] & ~Gin[1] & ~Gin[0]);

    // Define state transitions
    current_state = Gin;
    next_state = Gout;
end

// Monitor current and next states
initial begin
	#2
    $monitor("Current State: %b, Pz: %b, Q1: %b, st: %b, ip: %b, mul: %b, Next State: %b, Outputs: %b", current_state, Pz, Q1, st, ip, mul, next_state, out);
end

endmodule

