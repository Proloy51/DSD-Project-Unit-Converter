//-----------------------------------------------------------------------------
//
// Title       : P_check
// Design      : dsd_project
// Author      : proloykarmakar2022@outlook.com
// Company     : KUET
//
//-----------------------------------------------------------------------------
//
// File        : C:/Users/prolo/OneDrive/Desktop/4-2/DSD Lab/DSD_Project_Unit_Converter/dsd_project/src/ParallelAdder.v
// Generated   : Fri Jan 10 22:03:53 2025
// From        : Interface description file
// By          : ItfToHdl ver. 1.0
//
//-----------------------------------------------------------------------------
//
// Description : 
//
//-----------------------------------------------------------------------------

`timescale 1ps / 1ps

//{{ Section below this comment is automatically maintained
//    and may be overwritten
//{module {P_checker}}

module P_checker (
    input [3:0] P,    
    output reg Pz     
);

    always @(*) begin
        if (~|P)       // Check if all bits of P are 0
            Pz = 1;
        else
            Pz = 0;
    end

endmodule

