//-----------------------------------------------------------------------------
//
// Title       : Right_shift_FQB
// Design      : dsd_project
// Author      : proloykarmakar2022@outlook.com
// Company     : KUET
//
//-----------------------------------------------------------------------------
//
// File        : C:/Users/prolo/OneDrive/Desktop/4-2/DSD Lab/DSD_Project_Unit_Converter/dsd_project/src/ParallelAdder.v
// Generated   : Fri Jan 10 22:03:53 2025
// From        : Interface description file
// By          : ItfToHdl ver. 1.0
//
//-----------------------------------------------------------------------------
//
// Description : 
//
//-----------------------------------------------------------------------------

`timescale 1ps / 1ps

//{{ Section below this comment is automatically maintained
//    and may be overwritten
//{module {Right_shift_FQB}}

module Right_shift_FQB (
	input clk,
    input [3:0] B,    
    input [3:0] Q,    
    input F,         
    output reg [3:0] Q_out,  
    output reg [3:0] B_out    
);

    always @(posedge clk) begin
        {Q_out, B_out} = {F, Q, B} >> 1;
    end

endmodule

