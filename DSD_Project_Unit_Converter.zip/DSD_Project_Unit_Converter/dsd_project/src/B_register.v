//
// Title       : A register
// Design      : dsd_project
// Author      : proloykarmakar2022@outlook.com
// Company     : KUET
//
//-----------------------------------------------------------------------------
//
// File        : C:/Users/prolo/OneDrive/Desktop/4-2/DSD Lab/DSD_Project_Unit_Converter/dsd_project/src/ParallelAdder.v
// Generated   : Fri Jan 10 22:03:53 2025
// From        : Interface description file
// By          : ItfToHdl ver. 1.0
//
//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------

`timescale 1ps / 1ps

//{{ Section below this comment is automatically maintained
//    and may be overwritten
//{module {Bf_register}}

module B_register (
    input clk,        
    input L,         
    input D,         
    output reg B    
);

    always @(posedge clk) begin
        if (L) begin
            B <= D;  
        end
    end
	
	initial
		begin
			B = 4'b1010;
	end

endmodule

