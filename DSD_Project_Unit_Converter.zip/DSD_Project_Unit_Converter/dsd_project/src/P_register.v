//
// Title       : A register
// Design      : dsd_project
// Author      : proloykarmakar2022@outlook.com
// Company     : KUET
//
//-----------------------------------------------------------------------------
//
// File        : C:/Users/prolo/OneDrive/Desktop/4-2/DSD Lab/DSD_Project_Unit_Converter/dsd_project/src/ParallelAdder.v
// Generated   : Fri Jan 10 22:03:53 2025
// From        : Interface description file
// By          : ItfToHdl ver. 1.0
//
//-----------------------------------------------------------------------------
// Description : 
//
//-----------------------------------------------------------------------------

`timescale 1ps / 1ps

//{{ Section below this comment is automatically maintained
//    and may be overwritten
//{module {P_register}}

	module P_register (
	    input clk,             
	    input DP,              
	    output reg [3:0] P     
	);

    initial begin
        P = 4'b0100;
    end

    always @(posedge clk) begin
        if (DP) begin
            P <= P - 1;  
        end
    end

endmodule
