//-----------------------------------------------------------------------------
//
// Title       : FullAdder
// Design      : dsd_project
// Author      : proloykarmakar2022@outlook.com
// Company     : KUET
//
//-----------------------------------------------------------------------------
//
// File        : C:/Users/prolo/OneDrive/Desktop/4-2/DSD Lab/DSD_Project_Unit_Converter/dsd_project/src/FullAdder.v
// Generated   : Fri Jan 10 22:02:15 2025
// From        : Interface description file
// By          : ItfToHdl ver. 1.0
//
//-----------------------------------------------------------------------------
//
// Description : 
//
//-----------------------------------------------------------------------------

`timescale 1ps / 1ps

//{{ Section below this comment is automatically maintained
//    and may be overwritten
//{module {FullAdder}}

module FullAdder ( A ,B ,Cin ,Sum ,Cout );

input A;
wire A;
input B;
wire B;
input Cin;
wire Cin;
output Sum;
wire Sum;
output Cout;
wire Cout;

//}} End of automatically maintained section

// Enter your statements here //  

assign Sum = A ^ B ^ Cin;   
assign Cout = (A & B) | (B & Cin) | (A & Cin);

endmodule

