//-----------------------------------------------------------------------------
//
// Title       : A_B_sign_register
// Design      : dsd_project
// Author      : proloykarmakar2022@outlook.com
// Company     : KUET
//
//-----------------------------------------------------------------------------
//
// File        : C:/Users/prolo/OneDrive/Desktop/4-2/DSD Lab/DSD_Project_Unit_Converter/dsd_project/src/ParallelAdder.v
// Generated   : Sun Jan 19 18:27:53 2025
// From        : Interface description file
// By          : ItfToHdl ver. 1.0
//
//-----------------------------------------------------------------------------
//
// Description : 
//
//-----------------------------------------------------------------------------


`timescale 1ps / 1ps

module A_B_sign_register (
    output reg Bs, 
    output reg As
);

initial begin
    Bs = 1'b0;
    As = 1'b0;
end

endmodule

