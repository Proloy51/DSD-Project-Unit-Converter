//-----------------------------------------------------------------------------
//
// Title       : ParallelAdder
// Design      : dsd_project
// Author      : proloykarmakar2022@outlook.com
// Company     : KUET
//
//-----------------------------------------------------------------------------
//
// File        : C:/Users/prolo/OneDrive/Desktop/4-2/DSD Lab/DSD_Project_Unit_Converter/dsd_project/src/ParallelAdder.v
// Generated   : Fri Jan 10 22:03:53 2025
// From        : Interface description file
// By          : ItfToHdl ver. 1.0
//
//-----------------------------------------------------------------------------
//
// Description : 
//
//-----------------------------------------------------------------------------


`timescale 1ps / 1ps

module breadboard ();

    // 4-bit registers
    reg [3:0] Q, P,NS;

    // Single-bit registers
    reg As, Bs, Qs, F, mul, st, ip;
	
	//pla input wire
	wire E;

    //reg [3:0] current_state;  
    reg Pz, Q1, ES;        
    wire [3:0] next_state, current_state;    
    //wire [8:0] temp_pla_output;
	wire [8:0] pla_output;

    wire clock;
	

    // Outputs from modules
    /*wire [3:0] adder1_out, adder2_out, adder3_out;
	wire adder1_cout, adder2_cout, adder3_cout;
    wire xor_out, Pz_out;
    wire [3:0] ones_complement_out;
    wire [3:0] Q_out, B_out;	*/

    // Instantiate the modules
    clock master_clock (
        .clock(clock)
    );
	
	sequence_register sq_register (
        .clk(clock),
        .next_state(next_state),
        .current_state(current_state)
    );
	
	/*E_register e_register (
	    .clk(clk),   
	    .LE(1'b0),       	
	    .RE(1'b0),       	
	    .in(1'b0),        	
	    .E(E)             	
	);
	
	Aes_register aes_reg (
        .clk(clk),
        .Y(pla_output[5]),
        .Aes(Aes)
    );

    pla control_pla (
		.clk(clock),
        .Gin(current_state),
        .Pz(Pz),
        .Q1(Q1),
        .E(E),
        .ES(Aes),
        .Gout(next_state),
        .out(pla_output)
    );*/	
	
	pla control_pla (
        .Gin(current_state),
        .Pz(Pz),
        .Q1(Q1),
        .mul(mul),
        .st(st), 
		.ip(ip),
        .Gout(next_state),
        .out(pla_output)
    );
	
    ALU alu(   
	   .clk(clock),
       .current_state(current_state),
	   .pla_output(pla_output)
	);	 
	

    initial begin
        // Initialize registers
        //current_state = 4'b0000;  // Initial state
        Pz = 0;
        Q1 = 0;
        Q = 4'b0000;
        P = 4'b0100; 
        As = 0;
        Bs = 0;
        Qs = 0;
        F = 0; 
		mul = 1;
		st = 1;
		ip = 1;
    end

    // State update and operation execution logic
    always @(posedge clock) begin		
		
        // Termination condition
        if (current_state == 4'b1000) begin
            $stop;  // Stop the simulation
        end
    end

endmodule